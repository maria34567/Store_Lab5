using Microsoft.EntityFrameworkCore;
using Store.Common;
using Store.Infrastructure;
using Store.Infrastructure.Models;
using Store.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);
var dbPath = Path.GetFullPath(Path.Combine(builder.Environment.ContentRootPath, "..", "store_lab3.db"));
builder.Services.AddDbContext<StoreContext>(o => o.UseSqlite($"Data Source={dbPath}"));
builder.Services.AddScoped<IGuidRepository<ElectronicsModel>, GuidRepository<ElectronicsModel>>();
builder.Services.AddScoped<ICrudServiceAsync<Electronics>, ElectronicsCrudService>();
builder.Services.AddScoped<IRepository<CategoryModel>, EfRepository<CategoryModel>>();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var app = builder.Build();
await using (var scope = app.Services.CreateAsyncScope())
{
    var db = scope.ServiceProvider.GetRequiredService<StoreContext>();
    await db.Database.MigrateAsync();
    if (!await db.Categories.AnyAsync())
    {
        db.Categories.Add(new CategoryModel { Id = 1, Name = "Електроніка" });
        await db.SaveChangesAsync();
    }
}
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.Run();
